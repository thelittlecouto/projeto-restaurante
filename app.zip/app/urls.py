from django.contrib import admin
from django.urls import path, include
from .views import home, inner , comanda

urlpatterns = [
    path('', home),
    path('inner-page.html', inner),
    path('comanda.html', comanda)
]